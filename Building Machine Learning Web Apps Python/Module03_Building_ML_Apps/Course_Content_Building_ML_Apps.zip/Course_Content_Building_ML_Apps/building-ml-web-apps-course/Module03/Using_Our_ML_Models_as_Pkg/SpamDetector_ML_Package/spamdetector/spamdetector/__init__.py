__version__ = '0.0.1'
from .spamdetector import CommentClassifier
