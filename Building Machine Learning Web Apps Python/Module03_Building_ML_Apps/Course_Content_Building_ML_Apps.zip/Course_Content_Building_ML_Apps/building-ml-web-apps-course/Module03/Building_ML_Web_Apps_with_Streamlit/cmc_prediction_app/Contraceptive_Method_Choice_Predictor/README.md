#### Predicting Contraceptive Method Choice with Machine Learning

#### Plan
+ EDA
+ Build Models
+ Model Interpretation
+ Productionize with Streamlit



#### Streamlit App Image :: Home
![](images/images_app01.png)

#### Streamlit App Image ::EDA
![](images/images_app02.png)

#### Streamlit App Image ::EDA
![](images/images_app03.png)

#### Streamlit App Image ::EDA
![](images/images_app04.png)

#### Streamlit App Image ::EDA
![](images/images_app05.png)

#### Streamlit App Image :: Chart
![](images/images_app06.png)

#### Streamlit App Image
![](images/images_app07.png)

#### Streamlit App Image :: Select Model
![](images/images_app08.png)

#### Streamlit App Image ::Model Prediction
![](images/images_app09.png)







##### By
+ Jesse E.Agbe(JCharis)
+ Jesus Saves@JCharisTech
+ Streamlit is Awesome
